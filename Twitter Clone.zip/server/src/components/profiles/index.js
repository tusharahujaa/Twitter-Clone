module.exports.Profile = require('./profile.model');

module.exports.profileRoutes = require('./profile.routes');

module.exports.profileController = require('./profile.controller');
