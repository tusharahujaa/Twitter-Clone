module.exports.User = require('./user.model');

module.exports.userRoutes = require('./user.routes');

module.exports.userController = require('./user.controller');
